# corejava
created this for an internall trainig.
