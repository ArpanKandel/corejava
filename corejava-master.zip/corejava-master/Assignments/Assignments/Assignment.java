package Assignments;


/**
 * 
 * @author arpan
 * @since Jan 2019
 *
 */
public class Assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
