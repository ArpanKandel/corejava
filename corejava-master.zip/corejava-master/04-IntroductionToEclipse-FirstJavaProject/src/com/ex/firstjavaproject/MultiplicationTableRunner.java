package com.ex.firstjavaproject;

public class MultiplicationTableRunner {

	public static void main(String[] args) {
		MultiplicationTable table = new MultiplicationTable();
		table.print();
		
		//table.print(6);
		//table.print(6, 11, 20);
	}

}
